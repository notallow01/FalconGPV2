# Running the panel on Replit

- Start the app with `npm start`.
- The Replit workflow runs `PORT=5000 npm start` so the web preview can reach it.
- The app stores its SQLite database in `database.db` in the project root.

The sign-in page should load in the Replit preview after the workflow starts.
